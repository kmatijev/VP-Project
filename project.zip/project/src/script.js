const maleData = [];
const femaleData = [];
const maleColors = ['#4daf4a', '#377eb8', '#ff7f00'];
const femaleColors = ['#e41a1c', '#377eb8', '#4daf4a'];

// Load data and create initial charts
d3.csv("../data/openpowerlifting_edit.csv", (row, i) => {
    if (i % 100 !== 0) return null;
    return {
        BodyweightKg: +row.BodyweightKg,
        Best3BenchKg: +row.Best3BenchKg,
        Best3SquatKg: +row.Best3SquatKg,
        Best3DeadliftKg: +row.Best3DeadliftKg,
        Sex: row.Sex
    };
}).then(d => {
    maleData.push(...d.filter(d => d.Sex === 'M'));
    femaleData.push(...d.filter(d => d.Sex === 'F'));
    createScatterPlot('scatter-plot-male', []);
    createScatterPlot('scatter-plot-female', []);
    createPieChart('pie-chart-male', calculateLiftData(maleData), '#2f5f98');
    createPieChart('pie-chart-female', calculateLiftData(femaleData), '#995d74');

}).catch(error => {
    console.error('Error loading or parsing data:', error);
});

// Toggle lift visibility
function toggleLift(lift) {
    const liftButton = document.getElementById(lift);
    const liftSelected = liftButton.classList.contains('selected');

    liftButton.classList.toggle('selected');
    updateScatterPlots();
}

function calculateLiftData(data) {
    // Define the lifts
    const lifts = ['Squat', 'Bench', 'Deadlift'];

    // Calculate the total weight lifted for all exercises
    const totalWeight = d3.sum(data, d => d3.sum(lifts.map(lift => d[`Best3${lift}Kg`])));

    // Calculate the percentage of total weight lifted for each lift
    const result = lifts.map((lift, i) => ({
        name: lift,
        value: d3.sum(data, d => d[`Best3${lift}Kg`]),
        percentage: (d3.sum(data, d => d[`Best3${lift}Kg`]) / totalWeight) * 100
    }));

    return result;
}
function createPieChart(svgId, data, color) {
    const width = 300;
    const height = 250;
    const radius = Math.min(width, height) / 2;

    const pie = d3.pie().sort(null).value(d => d.percentage);
    const arc = d3.arc().innerRadius(radius * 0.5).outerRadius(radius);
    const initialArc = d3.arc().innerRadius(0).outerRadius(0); // Initial arc with zero radii

    const svg = d3.select("#" + svgId)
        .append("svg")
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

    const chart = pie(data);

    const arcs = svg.selectAll(".arc")
        .data(chart)
        .enter()
        .append("g")
        .attr("class", "arc");

    const paths = arcs.append("path")
        .attr("d", initialArc)  // Start with initial arc
        .attr('fill', color)  // Set color directly
        .attr("stroke", "white")
        .style("stroke-width", "2px")
        .style("opacity", 0.7);

    paths.transition()
        .duration(2000)  // Duration of the entry animation
        .attrTween("d", d => {
            let angleInterpolation = d3.interpolate(d.startAngle, d.endAngle);
            let innerRadiusInterpolation = d3.interpolate(0, radius * 0.5);
            let outerRadiusInterpolation = d3.interpolate(0, radius);
            return t => {
                d.endAngle = angleInterpolation(t);
                return arc.innerRadius(innerRadiusInterpolation(t)).outerRadius(outerRadiusInterpolation(t))(d);
            };
        });

    arcs.append("text")
        .attr("transform", d => "translate(" + arc.centroid(d) + ")")
        .attr("dy", "0.35em")
        .attr("text-anchor", "middle")
        .style("fill", "white")  // Set text color to white
        .style("opacity", 0)  // Start with text invisible
        .text(d => `${d.data.name}`);

    // Add text animation to fade in after pie chart animation
    arcs.selectAll("text")
        .transition()
        .delay(2000)  // Delay until pie chart animation completes
        .duration(1000)
        .style("opacity", 1);
}
// Create scatter plots
function createScatterPlot(svgId, data) {
    const margin = { top: -20, right: 40, bottom: 70, left: 60 };
    const width = 350 - margin.left - margin.right;
    const height = 300 - margin.top - margin.bottom;

    const x = d3.scaleLinear().range([0, width]);
    const y = d3.scaleLinear().range([height, 0]);

    const svg = d3.select("#" + svgId).append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    // Create a transition for the whole SVG element
    svg.transition().duration(1000)
        .style("opacity", 1);

    // Define axes
    const xAxis = d3.axisBottom(x);
    const yAxis = d3.axisLeft(y);

    // Scale domains
    x.domain([0, d3.max(data, d => d.BodyweightKg)]);
    y.domain([0, d3.max(data, d => d.Total)]);

    // Append axes
    svg.append("g")
        .attr("class", "x-axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis);

    svg.append("g")
        .attr("class", "y-axis")
        .call(yAxis);

    svg.append("text") // X-axis label
        .attr("class", "x-axis-label")
        .attr("text-anchor", "middle")
        .attr("x", width / 2)
        .attr("y", height + margin.bottom - 30) // Adjusted position
        .text("Competitor Weight (kg)");

    svg.append("text") // Y-axis label
        .attr("class", "y-axis-label")
        .attr("text-anchor", "middle")
        .attr("transform", "rotate(-90)")
        .attr("x", -height / 2)
        .attr("y", -margin.left + 20) // Adjusted position
        .text("Total Weight Lifted (kg)");

    // Add data points with transition
    svg.selectAll(".datapoint")
        .data(data)
        .enter().append("circle")
        .attr("class", "datapoint")
        .attr("r", 0) // Start with radius 0 for entry animation
        .attr("cx", d => x(d.BodyweightKg))
        .attr("cy", d => y(d.Total))
        //.style("fill", color)
        .transition().duration(1000) // Duration of the entry animation
        .attr("r", 2.5) // End with the desired radius
        .attr("cx", d => x(d.BodyweightKg))
        .attr("cy", d => y(d.Total));
}       

// Update scatter plots
function updateScatterPlots() {
    const selectedLifts = document.querySelectorAll('.nav-bar button.selected');
    const selectedLiftTypes = Array.from(selectedLifts).map(lift => lift.id.toLowerCase());

    const calculateTotal = (d) => {
        let total = 0;
        if (selectedLiftTypes.includes('squat')) total += d.Best3SquatKg;
        if (selectedLiftTypes.includes('bench')) total += d.Best3BenchKg;
        if (selectedLiftTypes.includes('deadlift')) total += d.Best3DeadliftKg;
        return total;
    };

    const maleFilteredData = maleData.map(d => ({
        BodyweightKg: d.BodyweightKg,
        Total: calculateTotal(d)
    })).filter(d => !isNaN(d.Total) && d.Total > 0);

    const femaleFilteredData = femaleData.map(d => ({
        BodyweightKg: d.BodyweightKg,
        Total: calculateTotal(d)
    })).filter(d => !isNaN(d.Total) && d.Total > 0);

    // Fixed domain for x and y axes
    const xMax = Math.max(
        d3.max(maleFilteredData, d => d.BodyweightKg),
        d3.max(femaleFilteredData, d => d.BodyweightKg)
    );

    const yMax = Math.max(
        d3.max(maleFilteredData, d => d.Total),
        d3.max(femaleFilteredData, d => d.Total)
    );

    const xScale = d3.scaleLinear().domain([0, xMax]).range([0, 350 - 50]);
    const yScale = d3.scaleLinear().domain([0, yMax]).range([300 - 50, 0]);

    // Select and update existing graphs and data
    const maleSvg = d3.select("#scatter-plot-male").select("svg g");
    const femaleSvg = d3.select("#scatter-plot-female").select("svg g");
    maleSvg.select(".x-axis").transition().duration(500).call(d3.axisBottom(xScale));
    maleSvg.select(".y-axis").transition().duration(500).call(d3.axisLeft(yScale));
    femaleSvg.select(".x-axis").transition().duration(500).call(d3.axisBottom(xScale));
    femaleSvg.select(".y-axis").transition().duration(500).call(d3.axisLeft(yScale));

    const maleDataPoints = maleSvg.selectAll(".datapoint").data(maleFilteredData);
    const femaleDataPoints = femaleSvg.selectAll(".datapoint").data(femaleFilteredData);

    // Enter, update, and exit for male data points
    maleDataPoints.enter().append("circle")
        .attr("class", "datapoint")
        .attr("r", 0) // Start with radius 0 for entry animation
        .attr("cx", d => xScale(d.BodyweightKg))
        .attr("cy", d => yScale(d.Total))
        .style("fill", '#2f5f98')
        .style("opacity", 0) // Start with opacity 0 for fade-in effect
        .transition().duration(1000) // Duration of the entry animation
        .attr("r", 2.5) // End with the desired radius
        .style("opacity", 1); // End with full opacity

    maleDataPoints.transition().duration(500)
        .attr("cx", d => xScale(d.BodyweightKg))
        .attr("cy", d => yScale(d.Total));

    maleDataPoints.exit().transition().duration(500).style("opacity", 0).remove();

    // Enter, update, and exit for female data points
    femaleDataPoints.enter().append("circle")
        .attr("class", "datapoint")
        .attr("r", 0) // Start with radius 0 for entry animation
        .attr("cx", d => xScale(d.BodyweightKg))
        .attr("cy", d => yScale(d.Total))
        .style("fill", '#995d74')
        .style("opacity", 0) // Start with opacity 0 for fade-in effect
        .transition().duration(1000) // Duration of the entry animation
        .attr("r", 2.5) // End with the desired radius
        .style("opacity", 1); // End with full opacity

    femaleDataPoints.transition().duration(500)
        .attr("cx", d => xScale(d.BodyweightKg))
        .attr("cy", d => yScale(d.Total));

    femaleDataPoints.exit().transition().duration(500).style("opacity", 0).remove();

    // Update pie charts
    const malePieData = calculateLiftData(maleFilteredData, maleColors);
    const femalePieData = calculateLiftData(femaleFilteredData, femaleColors);
}